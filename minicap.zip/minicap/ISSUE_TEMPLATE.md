**What is the issue or idea you have?**

**Have you tried STF?**
<!-- Minicap was made for STF, and STF contains many workarounds for edge cases. -->
<!-- If something doesn't work, try STF first. We only accept bug reports for issues that don't work in STF. -->

